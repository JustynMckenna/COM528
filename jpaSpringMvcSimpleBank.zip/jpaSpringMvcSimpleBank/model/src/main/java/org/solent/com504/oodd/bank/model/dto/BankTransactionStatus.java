package org.solent.com504.oodd.bank.model.dto;

public enum BankTransactionStatus {

    SUCCESS, FAIL
}
