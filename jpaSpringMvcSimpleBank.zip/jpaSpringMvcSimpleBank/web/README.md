
# Java Web WAR

To run Tomcat as an embedded service using Tomcat

```
mvn spring-boot:run
```

then navigate to http://localhost:8080/






