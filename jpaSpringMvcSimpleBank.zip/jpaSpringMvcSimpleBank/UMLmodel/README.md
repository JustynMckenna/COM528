
# UML Models

## class diagrams

### A simple UML model of the project 

![alt text](../UMLmodel/images/classDiagram.png "Figure classDiagram.png" )



