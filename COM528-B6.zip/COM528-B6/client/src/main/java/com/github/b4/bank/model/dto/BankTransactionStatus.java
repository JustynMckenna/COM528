package com.github.b4.bank.model.dto;

public enum BankTransactionStatus {

    SUCCESS, FAIL
}
